////////////////////////Contexto
/*var i = "global";
function foo() {
    var i = "local";
    console.log(i);
}
foo();
console.log(i);*/
/////////////////////////

////////////////////////Undefined
/*console.log(i);
var i;
console.log(i);
i = 1;
console.log(i);

console.log(x);
let x = 1;*/
////////////////////////

////////////////////////Var, Let
/*function foo() {
    if(true){
        let i = "let";
        var j = "var"
        console.log(i);
        console.log(j);
    }
    console.log("-> " + j);
    console.log("-> " + i);
}
foo()*/
////////////////////////

////////////////////////Const
// const i = 0;
// i = 1;

/* const user = {name: "Andres"};
user.name = "Carlos";
console.log(user);
user.surname = "Ramirez";
console.log(user); */
////////////////////////

////////////////////////Arrow fuctions
// let saludo = (nombre, tratamiento) => {
//     alert('Hola ' + tratamiento + ' ' + nombre)
// }
// let saludo = (nombre, tratamiento) => alert('Hola ' + tratamiento + ' ' + nombre);
// saludo('Andres', 'Sr.');

////////////Operador **
/* var x = 5;
console.log(x ** 2);

var x = 5;
console.log(Math.pow(x,2)); */


var cars = ["BMW", "Volvo", "Honda", "Ford", "Fiat", "Audi"];

/*console.log(cars.map(function(elemento){ 
    return elemento.length;
}));

console.log(cars.map((elemento) => {
    return elemento.length;
}));

console.log(cars.map((car) => car));*/

/////////////////////////Find
/* var numbers = [4, 9, 16, 25, 29];
console.log(numbers.find(foo));
console.log(numbers.findIndex(foo));

function foo(num) {
  return num > 3;
} */

/////////////////////Integers
// console.log(Number.isInteger(10));
// console.log(Number.isInteger(10.5));

////////////////////Finite
// console.log(isFinite(10/0));
// console.log(isFinite(10/1));

//////////////////////

//Ecma 6
 /*function Persona(name, timeInMillis) {
    var edad = 0;

    setInterval(() => {
        edad++;
        if(timeInMillis == 1000){
          console.log(name + ": " + edad);
        } else {
          console.log("------> " + name + ": " + edad);
        }
    }, timeInMillis)
}
 
 var p = new Persona("Andres", 3000);
 var p = new Persona("Carlos", 1000);*/

///////////////////No puede usarse como constructor
/*var Persona1 = function() {}
var Persona = () => {};

console.log(new Persona1());
console.log(new Persona());*/

//////////////////Cuerpo de una funcion
/*var func = x => x * x;                  
// sintaxis de cuerpo conciso, el "return" está implícito

var func = (x, y) => { return x + y; }; 
// con cuerpo de bloque, se necesita "return" explícito*/

/*var simple = a => a > 15 ? 15 : a; 
console.log(simple(16));
console.log(simple(10));*/

////////////////////Destructuring
//Extraccion de datos en arreglos u objetos

// var foo = ["uno ", "dos ", "tres"];

// // sin destructuración
// var uno  = foo[0];
// var dos  = foo[1];
// var tres = foo[2]; // asignación en tres lineas

// // con destructuración
// var [uno, dos, tres] = foo; // asignación en una sola linea

// console.log(uno + dos + tres);

//////////////////////Multiples retornos
/* // function foo() {
//     return [1, 2];
// };
var foo = func => [1, 2];
console.log(f()); */

/////////////////////Objetos anidados
/* var metadata = {
    title: "Scratchpad",
    translations: [
       {
        locale: "mx",
        localization_tags: [ ],
        last_edit: "2019-03-12T19:43:37",
        url: "/de/docs/Tools/Scratchpad",
        title: "JavaScript-Umgebung"
       }
    ],
    url: "/es-MX/docs/Tools/Scratchpad"
};

var { title: englishTitle, translations: [{ title: localeTitle }] } = metadata;

console.log(englishTitle);
console.log(localeTitle); */

///////////////////Iteraciones
/* var people = [
    {
      name: "Carlos",
      family: {
        mother: "Maria",
        father: "Andres",
        sister: "Vannessa"
      },
      age: 25
    },
    {
      name: "Lorena",
      family: {
        mother: "Tere",
        father: "Arturo",
        brother: "Sergio"
      },
      age: 24
    }
  ];
  
  for (var {name: n, family: { father: f } } of people) {
    console.log("Name: " + n + ", Father: " + f);
  } */